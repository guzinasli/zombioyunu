import { useEffect, useCallback } from "react";
import { useGame } from "../lib/stores/useGame";
import { useMaze } from "../lib/stores/useMaze";
import { useAudio } from "../lib/stores/useAudio";
import GameCanvas from "./GameCanvas";
import GameUI from "./GameUI";

const MazeGame = () => {
  const { phase, start, restart } = useGame();
  const { 
    currentLevel, 
    playerPosition, 
    targetPosition, 
    maze,
    movePlayer, 
    nextLevel, 
    resetLevel,
    initializeGame 
  } = useMaze();
  const { playSuccess, playHit } = useAudio();

  // Initialize the game
  useEffect(() => {
    initializeGame();
    start();
  }, [initializeGame, start]);

  // Handle keyboard input
  const handleKeyPress = useCallback((event: KeyboardEvent) => {
    if (phase !== "playing") return;

    let dx = 0, dy = 0;

    switch (event.key) {
      case "ArrowUp":
      case "w":
      case "W":
        dy = -1;
        break;
      case "ArrowDown":
      case "s":
      case "S":
        dy = 1;
        break;
      case "ArrowLeft":
      case "a":
      case "A":
        dx = -1;
        break;
      case "ArrowRight":
      case "d":
      case "D":
        dx = 1;
        break;
      case "r":
      case "R":
        resetLevel();
        return;
      default:
        return;
    }

    const moved = movePlayer(dx, dy);
    if (!moved) {
      playHit(); // Play hit sound when hitting a wall
    }
  }, [phase, movePlayer, playHit, resetLevel]);

  // Check win condition
  useEffect(() => {
    if (playerPosition.x === targetPosition.x && playerPosition.y === targetPosition.y) {
      playSuccess();
      setTimeout(() => {
        nextLevel();
      }, 1000);
    }
  }, [playerPosition, targetPosition, nextLevel, playSuccess]);

  // Setup keyboard listeners
  useEffect(() => {
    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [handleKeyPress]);

  // Handle restart
  const handleRestart = () => {
    resetLevel();
    restart();
    setTimeout(() => start(), 100);
  };

  return (
    <div style={{ 
      width: "100%", 
      height: "100%", 
      position: "relative",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <GameUI 
        level={currentLevel}
        phase={phase}
        onRestart={handleRestart}
      />
      <GameCanvas 
        maze={maze}
        playerPosition={playerPosition}
        targetPosition={targetPosition}
      />
    </div>
  );
};

export default MazeGame;
