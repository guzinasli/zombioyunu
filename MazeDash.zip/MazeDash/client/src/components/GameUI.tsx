import { GamePhase } from "../lib/stores/useGame";

interface GameUIProps {
  level: number;
  phase: GamePhase;
  onRestart: () => void;
}

const GameUI = ({ level, phase, onRestart }: GameUIProps) => {
  return (
    <div style={{
      position: "absolute",
      top: "20px",
      left: "50%",
      transform: "translateX(-50%)",
      zIndex: 10,
      textAlign: "center",
      color: "#ffffff",
      fontFamily: "Inter, sans-serif"
    }}>
      {/* Level Display */}
      <div style={{
        fontSize: "24px",
        fontWeight: "bold",
        marginBottom: "10px",
        backgroundColor: "rgba(0, 0, 0, 0.7)",
        padding: "10px 20px",
        borderRadius: "8px",
        border: "2px solid #444444"
      }}>
        Level {level}
      </div>

      {/* Game Status */}
      {phase === "ready" && (
        <div style={{
          fontSize: "16px",
          backgroundColor: "rgba(0, 100, 0, 0.8)",
          padding: "8px 16px",
          borderRadius: "6px",
          margin: "5px 0"
        }}>
          Ready to start!
        </div>
      )}

      {phase === "ended" && (
        <div style={{
          fontSize: "16px",
          backgroundColor: "rgba(100, 0, 0, 0.8)",
          padding: "8px 16px",
          borderRadius: "6px",
          margin: "5px 0"
        }}>
          Game Over
        </div>
      )}

      {/* Controls Display */}
      <div style={{
        position: "absolute",
        top: "100px",
        left: "50%",
        transform: "translateX(-50%)",
        fontSize: "14px",
        backgroundColor: "rgba(0, 0, 0, 0.7)",
        padding: "15px",
        borderRadius: "6px",
        border: "1px solid #444444",
        lineHeight: "1.5"
      }}>
        <div><strong>Controls:</strong></div>
        <div>Arrow Keys or WASD - Move</div>
        <div>R - Restart Level</div>
        <div style={{ marginTop: "10px", fontSize: "12px", color: "#cccccc" }}>
          Guide the blue ball to the green target!
        </div>
      </div>

      {/* Restart Button */}
      <button
        onClick={onRestart}
        style={{
          position: "absolute",
          top: "220px",
          left: "50%",
          transform: "translateX(-50%)",
          backgroundColor: "#0066ff",
          color: "white",
          border: "none",
          padding: "10px 20px",
          borderRadius: "6px",
          fontSize: "16px",
          cursor: "pointer",
          fontFamily: "Inter, sans-serif",
          fontWeight: "bold"
        }}
        onMouseOver={(e) => {
          e.currentTarget.style.backgroundColor = "#0044aa";
        }}
        onMouseOut={(e) => {
          e.currentTarget.style.backgroundColor = "#0066ff";
        }}
      >
        Restart Level
      </button>
    </div>
  );
};

export default GameUI;
