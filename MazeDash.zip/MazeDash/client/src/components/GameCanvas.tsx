import { useEffect, useRef } from "react";
import { Position } from "../lib/stores/useMaze";

interface GameCanvasProps {
  maze: number[][];
  playerPosition: Position;
  targetPosition: Position;
}

const GameCanvas = ({ maze, playerPosition, targetPosition }: GameCanvasProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    const cellSize = 30;
    const mazeWidth = maze[0]?.length || 0;
    const mazeHeight = maze.length;
    
    canvas.width = mazeWidth * cellSize;
    canvas.height = mazeHeight * cellSize;

    // Clear canvas
    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw maze
    for (let y = 0; y < mazeHeight; y++) {
      for (let x = 0; x < mazeWidth; x++) {
        const cell = maze[y][x];
        const xPos = x * cellSize;
        const yPos = y * cellSize;

        if (cell === 1) {
          // Wall
          ctx.fillStyle = "#666666";
          ctx.fillRect(xPos, yPos, cellSize, cellSize);
          
          // Add wall border
          ctx.strokeStyle = "#888888";
          ctx.lineWidth = 1;
          ctx.strokeRect(xPos, yPos, cellSize, cellSize);
        } else {
          // Path
          ctx.fillStyle = "#222222";
          ctx.fillRect(xPos, yPos, cellSize, cellSize);
        }
      }
    }

    // Draw target (green ball)
    const targetX = targetPosition.x * cellSize + cellSize / 2;
    const targetY = targetPosition.y * cellSize + cellSize / 2;
    const ballRadius = cellSize * 0.3;

    ctx.beginPath();
    ctx.arc(targetX, targetY, ballRadius, 0, 2 * Math.PI);
    ctx.fillStyle = "#00ff00";
    ctx.fill();
    ctx.strokeStyle = "#00aa00";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Draw player (blue ball)
    const playerX = playerPosition.x * cellSize + cellSize / 2;
    const playerY = playerPosition.y * cellSize + cellSize / 2;

    ctx.beginPath();
    ctx.arc(playerX, playerY, ballRadius, 0, 2 * Math.PI);
    ctx.fillStyle = "#0066ff";
    ctx.fill();
    ctx.strokeStyle = "#0044aa";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Add shine effect to balls
    // Player ball shine
    ctx.beginPath();
    ctx.arc(playerX - ballRadius * 0.3, playerY - ballRadius * 0.3, ballRadius * 0.2, 0, 2 * Math.PI);
    ctx.fillStyle = "#88bbff";
    ctx.fill();

    // Target ball shine
    ctx.beginPath();
    ctx.arc(targetX - ballRadius * 0.3, targetY - ballRadius * 0.3, ballRadius * 0.2, 0, 2 * Math.PI);
    ctx.fillStyle = "#88ff88";
    ctx.fill();

  }, [maze, playerPosition, targetPosition]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        border: "3px solid #444444",
        borderRadius: "8px",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.3)",
        backgroundColor: "#000000"
      }}
    />
  );
};

export default GameCanvas;
