import { useEffect, useState } from "react";
import "@fontsource/inter";
import MazeGame from "./components/MazeGame";

// Main App component
function App() {
  const [showGame, setShowGame] = useState(false);

  // Show the game once everything is loaded
  useEffect(() => {
    setShowGame(true);
  }, []);

  return (
    <div style={{ 
      width: '100vw', 
      height: '100vh', 
      position: 'relative', 
      overflow: 'hidden',
      backgroundColor: '#1a1a1a'
    }}>
      {showGame && <MazeGame />}
    </div>
  );
}

export default App;
