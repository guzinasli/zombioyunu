export interface MazeLevel {
  maze: number[][];
  playerStart: { x: number; y: number };
  target: { x: number; y: number };
}

// Simple maze generator using recursive backtracking
export function generateMaze(width: number, height: number): number[][] {
  // Ensure odd dimensions for proper maze generation
  const w = width % 2 === 0 ? width + 1 : width;
  const h = height % 2 === 0 ? height + 1 : height;
  
  // Initialize maze with walls
  const maze: number[][] = Array(h).fill(0).map(() => Array(w).fill(1));
  
  // Directions: up, right, down, left
  const directions = [
    [0, -2], [2, 0], [0, 2], [-2, 0]
  ];
  
  function isValid(x: number, y: number): boolean {
    return x >= 0 && x < w && y >= 0 && y < h;
  }
  
  function carve(x: number, y: number): void {
    maze[y][x] = 0; // Make current cell a path
    
    // Shuffle directions
    const shuffledDirections = [...directions].sort(() => Math.random() - 0.5);
    
    for (const [dx, dy] of shuffledDirections) {
      const nx = x + dx;
      const ny = y + dy;
      
      if (isValid(nx, ny) && maze[ny][nx] === 1) {
        // Carve the wall between current and next cell
        maze[y + dy/2][x + dx/2] = 0;
        carve(nx, ny);
      }
    }
  }
  
  // Start carving from (1, 1)
  carve(1, 1);
  
  return maze;
}

// Pre-designed levels for consistent gameplay
export const MAZE_LEVELS: MazeLevel[] = [
  // Level 1 - Simple
  {
    maze: [
      [1, 1, 1, 1, 1, 1, 1],
      [1, 0, 0, 0, 0, 0, 1],
      [1, 0, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 1],
      [1, 1, 1, 0, 0, 0, 1],
      [1, 1, 1, 1, 1, 1, 1]
    ],
    playerStart: { x: 1, y: 1 },
    target: { x: 5, y: 4 }
  },
  
  // Level 2 - Medium
  {
    maze: [
      [1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 0, 1, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 0, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 1],
      [1, 1, 1, 0, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 0, 0, 1],
      [1, 0, 1, 1, 0, 1, 1, 1, 1],
      [1, 0, 0, 0, 0, 0, 0, 0, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1]
    ],
    playerStart: { x: 1, y: 1 },
    target: { x: 7, y: 7 }
  },
  
  // Level 3 - Complex
  {
    maze: [
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
      [1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1],
      [1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1],
      [1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
      [1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
      [1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1],
      [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
      [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    ],
    playerStart: { x: 1, y: 1 },
    target: { x: 9, y: 9 }
  }
];

// Generate a level (use pre-designed first, then generate random ones)
export function getLevel(levelNumber: number): MazeLevel {
  if (levelNumber <= MAZE_LEVELS.length) {
    return MAZE_LEVELS[levelNumber - 1];
  }
  
  // Generate random maze for higher levels
  const size = Math.min(15 + Math.floor(levelNumber / 5) * 2, 25); // Increase size gradually
  const maze = generateMaze(size, size);
  
  // Find valid start and end positions
  const findEmptyPosition = (): { x: number, y: number } => {
    for (let y = 1; y < maze.length - 1; y++) {
      for (let x = 1; x < maze[0].length - 1; x++) {
        if (maze[y][x] === 0) {
          return { x, y };
        }
      }
    }
    return { x: 1, y: 1 }; // Fallback
  };
  
  const findFarEmptyPosition = (startX: number, startY: number): { x: number, y: number } => {
    let bestPos = { x: startX, y: startY };
    let maxDistance = 0;
    
    for (let y = 1; y < maze.length - 1; y++) {
      for (let x = 1; x < maze[0].length - 1; x++) {
        if (maze[y][x] === 0) {
          const distance = Math.abs(x - startX) + Math.abs(y - startY);
          if (distance > maxDistance) {
            maxDistance = distance;
            bestPos = { x, y };
          }
        }
      }
    }
    
    return bestPos;
  };
  
  const playerStart = findEmptyPosition();
  const target = findFarEmptyPosition(playerStart.x, playerStart.y);
  
  return {
    maze,
    playerStart,
    target
  };
}
