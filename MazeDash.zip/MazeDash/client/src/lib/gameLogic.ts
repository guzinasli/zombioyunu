import { Position } from "./stores/useMaze";

// Check if a position is valid (not a wall and within bounds)
export function isValidPosition(maze: number[][], x: number, y: number): boolean {
  if (y < 0 || y >= maze.length || x < 0 || x >= maze[0].length) {
    return false;
  }
  return maze[y][x] === 0; // 0 = path, 1 = wall
}

// Check collision between two positions
export function checkCollision(pos1: Position, pos2: Position): boolean {
  return pos1.x === pos2.x && pos1.y === pos2.y;
}

// Calculate Manhattan distance between two positions
export function calculateDistance(pos1: Position, pos2: Position): number {
  return Math.abs(pos1.x - pos2.x) + Math.abs(pos1.y - pos2.y);
}

// Find path using simple BFS (for AI or hints)
export function findPath(maze: number[][], start: Position, end: Position): Position[] {
  const queue: { pos: Position; path: Position[] }[] = [{ pos: start, path: [start] }];
  const visited = new Set<string>();
  
  const directions = [
    { x: 0, y: -1 }, // up
    { x: 1, y: 0 },  // right
    { x: 0, y: 1 },  // down
    { x: -1, y: 0 }  // left
  ];
  
  while (queue.length > 0) {
    const { pos, path } = queue.shift()!;
    const key = `${pos.x},${pos.y}`;
    
    if (visited.has(key)) continue;
    visited.add(key);
    
    if (pos.x === end.x && pos.y === end.y) {
      return path;
    }
    
    for (const dir of directions) {
      const newPos = { x: pos.x + dir.x, y: pos.y + dir.y };
      const newKey = `${newPos.x},${newPos.y}`;
      
      if (!visited.has(newKey) && isValidPosition(maze, newPos.x, newPos.y)) {
        queue.push({
          pos: newPos,
          path: [...path, newPos]
        });
      }
    }
  }
  
  return []; // No path found
}

// Game difficulty scaling
export function getDifficultySettings(level: number) {
  return {
    mazeSize: Math.min(7 + Math.floor(level / 3) * 2, 21),
    hasMovingObstacles: level > 5,
    timeLimit: level > 10 ? Math.max(60 - level * 2, 30) : null,
    bonusTargets: level > 15 ? Math.floor(level / 10) : 0
  };
}
