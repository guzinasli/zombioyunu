import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import { getLevel, MazeLevel } from "../maze";
import { isValidPosition } from "../gameLogic";

export interface Position {
  x: number;
  y: number;
}

interface MazeState {
  currentLevel: number;
  maze: number[][];
  playerPosition: Position;
  targetPosition: Position;
  
  // Actions
  initializeGame: () => void;
  movePlayer: (dx: number, dy: number) => boolean;
  nextLevel: () => void;
  resetLevel: () => void;
  setLevel: (level: number) => void;
}

export const useMaze = create<MazeState>()(
  subscribeWithSelector((set, get) => ({
    currentLevel: 1,
    maze: [],
    playerPosition: { x: 0, y: 0 },
    targetPosition: { x: 0, y: 0 },
    
    initializeGame: () => {
      const level = getLevel(1);
      set({
        currentLevel: 1,
        maze: level.maze,
        playerPosition: level.playerStart,
        targetPosition: level.target
      });
    },
    
    movePlayer: (dx: number, dy: number) => {
      const { maze, playerPosition } = get();
      const newX = playerPosition.x + dx;
      const newY = playerPosition.y + dy;
      
      if (isValidPosition(maze, newX, newY)) {
        set({
          playerPosition: { x: newX, y: newY }
        });
        return true; // Movement successful
      }
      
      return false; // Movement blocked
    },
    
    nextLevel: () => {
      const { currentLevel } = get();
      const newLevel = currentLevel + 1;
      const level = getLevel(newLevel);
      
      set({
        currentLevel: newLevel,
        maze: level.maze,
        playerPosition: level.playerStart,
        targetPosition: level.target
      });
    },
    
    resetLevel: () => {
      const { currentLevel } = get();
      const level = getLevel(currentLevel);
      
      set({
        maze: level.maze,
        playerPosition: level.playerStart,
        targetPosition: level.target
      });
    },
    
    setLevel: (levelNumber: number) => {
      const level = getLevel(levelNumber);
      
      set({
        currentLevel: levelNumber,
        maze: level.maze,
        playerPosition: level.playerStart,
        targetPosition: level.target
      });
    }
  }))
);
