# Overview

This is a maze game built with React, TypeScript, and Express.js. The game features a 2D canvas-based maze where players navigate from a starting position to a target position across multiple levels. The application uses a full-stack architecture with a React frontend, Express backend, and PostgreSQL database integration via Drizzle ORM.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for build tooling
- **State Management**: Zustand with subscribeWithSelector middleware for game state, maze state, and audio management
- **UI Framework**: Tailwind CSS with Radix UI components for consistent design system
- **3D Graphics**: React Three Fiber and Drei for potential 3D features (though currently using 2D canvas)
- **Game Rendering**: HTML5 Canvas API for maze visualization and game graphics

## Backend Architecture
- **Server**: Express.js with TypeScript
- **API Design**: RESTful API structure with `/api` prefix for all endpoints
- **Development Setup**: Hot reload with Vite middleware in development mode
- **Storage Layer**: Pluggable storage interface supporting both in-memory and database implementations

## Data Storage
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Session Storage**: PostgreSQL-based session storage via connect-pg-simple

## Game State Management
- **Game Phases**: Three distinct phases (ready, playing, ended) managed via Zustand
- **Maze Generation**: Recursive backtracking algorithm for procedural maze creation
- **Level System**: Progressive difficulty with pre-designed levels and procedural generation
- **Player Movement**: Grid-based movement with collision detection and path validation

## Audio System
- **Sound Management**: Zustand store for audio state with mute/unmute functionality
- **Audio Assets**: Support for multiple audio formats (MP3, OGG, WAV)
- **Sound Effects**: Hit sounds, success sounds, and background music integration

## Input Handling
- **Keyboard Controls**: WASD and arrow key support for player movement
- **Touch Support**: Configured for mobile devices with touch-action prevention
- **Game Control**: Space bar for game start/restart functionality

# External Dependencies

## Core Frontend Dependencies
- **React Ecosystem**: React 18, React DOM, React Three Fiber for 3D capabilities
- **Build Tools**: Vite with TypeScript support, ESBuild for production builds
- **UI Libraries**: Radix UI component primitives, Tailwind CSS for styling
- **State Management**: Zustand for client-side state management
- **Data Fetching**: TanStack React Query for server state management

## Backend Dependencies
- **Server Framework**: Express.js with TypeScript support via TSX
- **Database**: Neon PostgreSQL serverless database
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Session Management**: connect-pg-simple for PostgreSQL session storage
- **Development**: Runtime error overlay via Replit plugin

## Development Tools
- **TypeScript**: Full TypeScript support across client and server
- **Linting/Formatting**: ESLint configuration for code quality
- **Asset Processing**: GLSL shader support, large file handling for 3D models
- **Hot Reload**: Vite HMR for development experience

## Styling and Design
- **CSS Framework**: Tailwind CSS with custom design tokens
- **Font System**: Inter font family via Fontsource
- **Component Library**: Extensive Radix UI component collection
- **Responsive Design**: Mobile-first approach with breakpoint management

## Utilities
- **Date Handling**: date-fns for date manipulation
- **Class Management**: clsx and class-variance-authority for conditional styling
- **Command Interface**: cmdk for command palette functionality
- **Icon System**: Lucide React for consistent iconography